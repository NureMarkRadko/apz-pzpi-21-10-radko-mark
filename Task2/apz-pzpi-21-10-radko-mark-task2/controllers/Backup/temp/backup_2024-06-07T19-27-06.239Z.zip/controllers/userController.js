const {User, Role, UserRole} = require('../models/models')
const {where} = require("sequelize");
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const nodemailer = require('nodemailer')
const languages = require('../locale/lang')
const checkController = require('../controllers/checkController')
const generateJwt = (UserId, FirstName, SecondName, Email, PhoneNumber, BirthDay, IsBanned, PassportCode, IOTCode) => {
    return jwt.sign({UserId, FirstName, SecondName, Email, PhoneNumber, BirthDay, IsBanned, PassportCode, IOTCode},
        process.env.SECRET_KEY,
        {expiresIn: '24h' }) //alive
}
const generateIOTCode = () => {
    return Math.floor(1000000 + Math.random() * 9000000).toString();
};

const sendWelcomeEmail = (email, password) => {
    const mailOptions = {
        from: process.env.MY_EMAIL,
        to: email,
        subject: 'Welcome to our Company', //header
        text: 'Welcome to our company! Thank you for registering. Your Authorization keys:\n' + //main text
            'login: ' + email +'\n' + 'password: ' + password
    }
    const transporter = nodemailer.createTransport({
        host: 'smtp-mail.outlook.com', //smtp
        port: 587,
        secure: false,
        auth: {
            user: process.env.MY_EMAIL,
            pass: process.env.DB_PASSWORD
        }

    })
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error(error);
            console.log('Error response:', error.response);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
}

class userController {
    async registration(req, res) {
        let preferredLang;
        try {
            const {
                FirstName, SecondName, Email, Password, PhoneNumber,
                BirthDay, PassportCode, Lang
            } = req.body;

            preferredLang = Lang;

            if (!FirstName || !SecondName || !Email || !Password || !PhoneNumber || !PassportCode || !BirthDay) {
                console.error("Some required fields are missing");
                return res.status(400).json({ error: languages.getLocalizedString(preferredLang, "Bad Request - Some required fields are missing") });
            }

            const candidate = await User.findOne({
                where: {
                    Email: Email,
                    PhoneNumber: PhoneNumber
                }
            });

            if (candidate) {
                console.error("User already created");
                return res.status(409).json({ error: languages.getLocalizedString(preferredLang, "Conflict - User already created") });
            }

            const hashPassword = await bcrypt.hash(Password, 5);
            const IOTCode = generateIOTCode();

            const user = await User.create({
                FirstName: FirstName,
                SecondName: SecondName,
                Email: Email,
                Password: hashPassword,
                PhoneNumber: PhoneNumber,
                BirthDay: BirthDay,
                PassportCode: PassportCode,
                IOTCode: IOTCode
            });

            if (!user) {
                console.error("User not created");
                return res.status(500).json({ error: languages.getLocalizedString(preferredLang, "Internal Server Error - User not created") });
            }

            const [clientRole, created] = await Role.findOrCreate({
                where: { RoleName: 'Client' },
                defaults: {
                    RoleDescription: 'This user can only be a client'
                }
            });

            await UserRole.create({
                UserUserId: user.UserId,
                RoleRoleId: clientRole.RoleId
            });

            const token = generateJwt(user.UserId, FirstName, SecondName, Email, PhoneNumber, BirthDay, user.IsBanned, PassportCode, IOTCode);

            if (!token) {
                console.error("Token not created");
                return res.status(500).json({ error: languages.getLocalizedString(preferredLang, "Internal Server Error - Token not created") });
            }

            sendWelcomeEmail(Email, Password);
            await checkController.create(req, res, user.UserId);
            
            return res.json("Registration successful");

        } catch (e) {
            console.error("Unexpected error:", e);
            return res.status(500).json({ error: languages.getLocalizedString(preferredLang, "Internal Server Error - Unexpected error") });
        }

    }

    async login(reg, res) {
        let preferredLang;
        try {
            const {Email, Password, Lang} = reg.body

            preferredLang = Lang;

            const user = await User.findOne({
                where: {Email: Email}
            })
            if (!user) {
                console.error("User is not found")
                return res.status(404).json({error: languages.getLocalizedString(preferredLang, "User is not found")})
            }

            if (user.IsBanned) {
                console.error("User is blocked")
                return res.status(402).json({error: languages.getLocalizedString(preferredLang, "User is blocked")})
            }

            let comparePassword = bcrypt.compareSync(Password, user.Password)
            if (!comparePassword) {
                console.error("Incorrect Password")
                return res.status(401).json({error: languages.getLocalizedString(preferredLang, "Incorrect password")});
            }
            const token = generateJwt(user.UserId, user.FirstName, user.SecondName, user.Email, user.PhoneNumber, user.BirthDay, user.IsBanned, user.PassportCode, user.IOTCode)
            return res.json({token})
        } catch (e) {
            console.error("Unexpected error:", e);
            return res.status(500).json({error: languages.getLocalizedString(preferredLang, "Internal Server Error - Unexpected error")});
        }
    }

    async ban(reg, res) {
        let preferredLang;
        try {
            const {UserId, Lang} = reg.body
            preferredLang = Lang;

            const user = await User.findOne({
                where: {UserId: UserId}
            })
            if (!user) {
                console.error("User is not found")
                return res.status(404).json({error: languages.getLocalizedString(preferredLang, "User is not found")})
            }

            await User.update({IsBanned: true}, {where: {UserId: UserId}});
            return res.json("User is banned")
        } catch (e) {
            console.error("Unexpected error:", e);
            return res.status(500).json({error: languages.getLocalizedString(preferredLang, "Internal Server Error - Unexpected error")});
        }
    }

    async unban(reg, res) {
        let preferredLang;
        try {
            const {UserId, Lang} = reg.body
            preferredLang = Lang;

            const user = await User.findOne({
                where: {UserId: UserId}
            })
            if (!user) {
                console.error("User is not found")
                return res.status(404).json({error: languages.getLocalizedString(preferredLang, "User is not found")})
            }

            await User.update({IsBanned: false}, {where: {UserId: UserId}});
            return res.json("User is unbanned")
        } catch (e) {
            console.error("Unexpected error:", e);
            return res.status(500).json({error: languages.getLocalizedString(preferredLang, "Internal Server Error - Unexpected error")});
        }
    }

    async check(reg, res) {
        try {
            const token = generateJwt(reg.user.UserId, reg.user.FirstName, reg.user.SecondName, reg.user.Email,
                reg.user.PhoneNumber, reg.user.BirthDay, reg.user.IsBanned, reg.user.PassportCode, reg.user.IOTCode)
            return res.json({token})
        } catch (e) {
            console.error(e)

        }
    }
}

module.exports = new userController()